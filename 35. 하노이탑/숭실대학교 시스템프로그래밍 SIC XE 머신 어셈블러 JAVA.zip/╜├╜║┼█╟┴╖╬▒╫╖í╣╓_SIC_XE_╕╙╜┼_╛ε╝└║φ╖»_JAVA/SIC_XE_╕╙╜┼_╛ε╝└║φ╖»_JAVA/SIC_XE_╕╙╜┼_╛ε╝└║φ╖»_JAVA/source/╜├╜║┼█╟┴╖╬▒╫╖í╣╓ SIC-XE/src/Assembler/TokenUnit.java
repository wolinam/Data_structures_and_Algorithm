package Assembler;

/**
 * ������� �� �ҽ��ڵ带 ��ū ������ �����ϴ� ���̺��̴�.
 * ���� ������ �ҽ� ���� ������ �����Ǿ�����.
 * @author SungHun
 *
 */
public class TokenUnit {
	private String label; //��
	private String operator; //���۷�����
	private String[] operand; //���۷���
	private String comment; //�ڸ�Ʈ
	private int locCtr; // locctr
	
	private String xAddress; //=X address
	private int machinOpcode; //���� Opcode
	private int machinOpIndex; //���� Index ����
	private int machineOpAddress; //���� �ּ�
	private int totalOpcode; //�����ּ�.
	
	private String oneLine; //�Ѱ��� ����
	private int section; //�� ������ section
	
	final public int maxOperand = 3; //�ִ� ���۷����� ũ��
	
	public TokenUnit(){
		label = null;
		operator = null;
		operand = new String[maxOperand];
		comment = null;
		locCtr = 0;
		section=0;
		xAddress="";
	}


	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getOperand(int index) {
		return operand[index];
	}

	public void setOperand(int index, String data) {
		this.operand[index] = data;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getOneLine() {
		return oneLine;
	}

	public void setOneLine(String oneLine) {
		this.oneLine = oneLine;
	}

	public int getSection() {
		return section;
	}

	public void setSection(int section) {
		this.section = section;
	}

	public int getMaxOperand() {
		return maxOperand;
	}


	public int getLocCtr() {
		return locCtr;
	}


	public void setLocCtr(int locCtr) {
		this.locCtr = locCtr;
	}


	public String[] getOperand() {
		return operand;
	}


	public void setOperand(String[] operand) {
		this.operand = operand;
	}


	public int getMachinOpcode() {
		return machinOpcode;
	}


	public void setMachinOpcode(int machinOpcode) {
		this.machinOpcode |= machinOpcode;
	}


	public int getMachinOpIndex() {
		return machinOpIndex;
	}


	public void setMachinOpIndex(int machinOpIndex) {
		this.machinOpIndex = machinOpIndex;
	}

	public void leftMachinOpcode(){
		this.machinOpcode <<=8;
	}
	
	public void rightMachinOpcode(){
		this.machinOpcode >>=8;
	}


	public String getxAddress() {
		return xAddress;
	}


	public void setxAddress(String xAddress) {
		this.xAddress = xAddress;
	}


	public int getTotalOpcode() {
		return totalOpcode;
	}


	public void setTotalOpcode(int totalOpcode) {
		this.totalOpcode = totalOpcode;
		//System.out.format("%08X%n",totalOpcode);

	}
	
	
}
