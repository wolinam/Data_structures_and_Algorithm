package Assembler;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyAssembler myAssembler = new MyAssembler();
		myAssembler.displayAssembler();
	}

}
