package Assembler;

public class Literal {
	private String literal;
	private int address;
	private int section;
	private int locCtr;

	public Literal() {
		this.literal = "";
		this.address = 0;
		this.section = 0;
		this.locCtr = 0;
	}
	public String getLiteral() {
		return literal;
	}
	public void setLiteral(String literal) {
		this.literal = literal;
	}
	public int getAddress() {
		return address;
	}
	public void setAddress(int address) {
		this.address = address;
	}
	public int getSection() {
		return section;
	}
	public void setSection(int section) {
		this.section = section;
	}
	public int getLocCtr() {
		return locCtr;
	}
	public void setLocCtr(int locCtr) {
		this.locCtr = locCtr;
	}

	
	
	
}
