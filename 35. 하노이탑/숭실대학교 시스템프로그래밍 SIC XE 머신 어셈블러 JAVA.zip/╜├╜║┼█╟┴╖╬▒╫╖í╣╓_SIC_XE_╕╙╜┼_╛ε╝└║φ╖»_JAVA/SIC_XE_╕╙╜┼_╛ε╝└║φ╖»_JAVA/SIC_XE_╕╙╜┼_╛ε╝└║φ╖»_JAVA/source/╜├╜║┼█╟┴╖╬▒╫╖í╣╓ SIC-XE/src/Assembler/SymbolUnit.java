package Assembler;
/**
 * Symbol�� �����ϴ� ���̺��̴�.
 * @author SungHun
 *
 */
public class SymbolUnit {
	private String symbol;
	private int addr;
	private int section;
	public SymbolUnit() {
		symbol = "";
		addr = 0;
		section = 0;
	}

	public SymbolUnit(String symbol, int addr, int section) {
		super();
		this.symbol = symbol;
		this.addr = addr;
		this.section = section;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public int getAddr() {
		return addr;
	}

	public void setAddr(int addr) {
		this.addr = addr;
	}

	public int getSection() {
		return section;
	}

	public void setSection(int section) {
		this.section = section;
	}	
	
}
